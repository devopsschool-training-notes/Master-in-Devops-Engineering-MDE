#!/bin/bash

#tests go here
echo 'Tests passed!'